Complete online documentation:
https://www.mediawiki.org/wiki/Extension:ConfirmAccount

== Breaking changes ==
=== MediaWiki 1.20 ===
$wgAccountRequestMinWords, $wgAccountRequestToS, $wgAccountRequestExtraInfo,
and $wgAllowAccountRequestFiles were all folded into a new variable called
$wgConfirmAccountRequestFormItems.

== Licensing ==
� GPL, Aaron Schulz
